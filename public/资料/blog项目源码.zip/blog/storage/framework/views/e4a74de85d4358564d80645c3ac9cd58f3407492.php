<style>
.wordpress{
    display: inline-block;
}
</style>
<!-- Bottom Banner -->
<div style="height:20px;"></div>
<!-- /.Bottom Banner -->
<!-- Footer -->
<!-- Footer Wrap -->
<div class="separator"></div>
<div id="footer-wrap">
    <div id="footer" class="layout-wrap">
        <!-- Footer Widgets -->
        <div id="footer-widgets">
        </div>
        <div class="clr"></div>
        <!-- /.Footer Widgets -->
    </div>
</div>
<!-- /.Footer Wrap -->
<!-- Footer Nav Wrap -->
<footer id="footer-nav-wrap">
    <div id="footer-nav" class="layout-wrap">
        <div id="footer-nav-left">
            <!-- Footer Nav -->
            <!-- /.Footer Nav -->
            <!-- Copyright -->
            <div id="footer-copyright">

            <?php echo config('webconfig.ICP'); ?>

            </div>
            <!-- /.Copyright -->
        </div>
        <div id="footer-nav-right">
            <!--  links -->
            <div id="footer-links-icons">
                <span class="footer-wordpress-link"> <a href="" target="_blank" rel="nofollow" class="wordpress"> <span class="tinicon-wordpress"><i class="fa fa-wordpress"></i></span> <br />WordPress </a> </span>
                <span class="footer-sinaweibo-link"> <a href="" target="_blank" rei="nofollow" class="sinaweibo"> <span class="tinicon-sinaweibo"><i class="fa fa-weibo"></i></span> <br />Weibo </a> </span>
                <span class="footer-qq-link"> <a href="" target="_blank" rei="nofollow" class="qq"> <span class="tinicon-qq"><i class="fa fa-qq"></i></span> <br />QQ </a> </span>
                <span class="footer-rss-link"> <a href="" target="_blank" class="rss"> <span class="tinicon-rss"><i class="fa fa-rss"></i></span> <br />RSS </a> </span>
            </div>
            <!-- /.links -->
            <div class="clear clr"></div>
        </div>
    </div>
</footer>
<script type="text/javascript">
    $('.site_loading').animate({'width':'100%'},50);  //第四个节点
</script>