<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>后台登录-X-admin2.0</title>
	<meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />

    <?php echo $__env->make('admin.public.styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.public.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</head>
<body class="login-bg">
    
    <div class="login">
        <div class="message">后台管理登录</div>

        <?php if(!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php if(is_object($errors)): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <li><?php echo e($errors); ?></li>
                    <?php endif; ?>
                </ul>
            </div>
        <?php endif; ?>
        <div id="darkbannerwrap"></div>
        
        <form method="post" class="layui-form" action="<?php echo e(url('admin/dologin')); ?>">
            <?php echo e(csrf_field()); ?>

            <input name="username" placeholder="用户名"  type="text" lay-verify="required" class="layui-input" >
            <hr class="hr15">
            <input name="password" lay-verify="required" placeholder="密码"  type="password" class="layui-input">
            <hr class="hr15">
            <input name="code" style="height:40px;width:150px;float:left;" lay-verify="required" placeholder="验证码"  type="text" class="layui-input">
            <img src="<?php echo e(url('admin/code')); ?>" alt="" style="float:right" onclick="this.src='<?php echo e(url('admin/code')); ?>?'+Math.random()">


            
                
            

            <hr class="hr15">
            <input value="登录" lay-submit lay-filter="login" style="width:100%;" type="submit">
            <hr class="hr20" >
        </form>
    </div>

    <script>
        $(function  () {
            layui.use('form', function(){
              var form = layui.form;
              // layer.msg('玩命卖萌中', function(){
              //   //关闭后的操作
              //   });
              //监听提交
              form.on('submit(login)', function(data){

              });
            });
        })







    </script>
    <script type="text/javascript">
        
            
            
            
        
    </script>


    <!-- 底部结束 -->
    <script>
    //百度统计可去掉
    var _hmt = _hmt || [];
    (function() {
      var hm = document.createElement("script");
      hm.src = "https://hm.baidu.com/hm.js?b393d153aeb26b46e9431fabaf0f6190";
      var s = document.getElementsByTagName("script")[0]; 
      s.parentNode.insertBefore(hm, s);
    })();
    </script>
</body>
</html>