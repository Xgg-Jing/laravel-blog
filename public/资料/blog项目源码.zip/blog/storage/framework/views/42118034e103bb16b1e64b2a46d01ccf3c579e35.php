<link rel="stylesheet" href="<?php echo e(asset('admin/css/font.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/css/xadmin.css')); ?>">