<div id="sidebar" class="clr">
    <div id="text-15" class="widget widget_text">
        <h3><span class="widget-title">猿圈QQ空间</span></h3>
        <div class="textwidget">
            <div align="center">
                <a target="_blank" href="#"><img id="previewImg" src="/home/images/login-logo-black.32.png" /></a>
            </div>
        </div>
    </div>
    <div id="search-3" class="widget widget_search">
        <h3><span class="widget-title">站内搜索</span></h3>
      
    </div>
    <div id="tinsubscribe-2" class="widget widget_tinsubscribe">
        <h3><span class="widget-title">邮件订阅</span></h3>
        <span id="subscribe-span"> <input type="text" name="subscribe" id="subscribe" placeholder="yourname@domain.com" /><button id="subscribe" class="btn btn-success">订阅</button> <p id="subscribe-msg" style="display:none;margin-top:5px;margin-left:auto;margin-right:auto;font-size:12px;color:#f00;"></p> </span>
    </div>

    <div id="tintagcloud-2" class="widget widget_tintagcloud">
        <h3><span class="widget-title">标签云</span></h3>
        <aside class="tags">
            <a href="" class="tag-link-675" title="26个话题" style="font-size: 12px;">饮食</a>
            <a href="" class="tag-link-355" title="20个话题" style="font-size: 12px;">青春</a>
            <a href="" class="tag-link-30" title="10个话题" style="font-size: 12px;">随笔</a>
            <a href="" class="tag-link-324" title="41个话题" style="font-size: 12px;">阅读</a>
            <a href="" class="tag-link-936" title="52个话题" style="font-size: 12px;">连载</a>
            <a href="" class="tag-link-1011" title="7个话题" style="font-size: 12px;">财富</a>
            <a href="" class="tag-link-211" title="28个话题" style="font-size: 12px;">读后感</a>
            <a href="" class="tag-link-1012" title="5个话题" style="font-size: 12px;">读书</a>
            <a href="" class="tag-link-991" title="47个话题" style="font-size: 12px;">语录</a>
            <a href="" class="tag-link-941" title="32个话题" style="font-size: 12px;">视野</a>
            <a href="" class="tag-link-176" title="76个话题" style="font-size: 12px;">观点</a>
            <a href="" class="tag-link-703" title="70个话题" style="font-size: 12px;">见闻</a>
            <a href="" class="tag-link-512" title="15个话题" style="font-size: 12px;">职场</a>
            <a href="" class="tag-link-222" title="12个话题" style="font-size: 12px;">童年</a>
            <a href="" class="tag-link-120" title="12个话题" style="font-size: 12px;">移动互联网</a>
            <a href="" class="tag-link-164" title="6个话题" style="font-size: 12px;">科技</a>
            <a href="" class="tag-link-585" title="17个话题" style="font-size: 12px;">科学</a>
            <a href="" class="tag-link-22" title="87个话题" style="font-size: 12px;">社会</a>
            <a href="" class="tag-link-140" title="90个话题" style="font-size: 12px;">生活</a>
            <a href="" class="tag-link-55" title="43个话题" style="font-size: 12px;">爱情</a>
            <a href="" class="tag-link-235" title="6个话题" style="font-size: 12px;">演讲</a>
            <a href="" class="tag-link-937" title="11个话题" style="font-size: 12px;">游记</a>
            <a href="" class="tag-link-51" title="86个话题" style="font-size: 12px;">段子</a>
            <a href="" class="tag-link-158" title="235个话题" style="font-size: 12px;">杂谈</a>
            <a href="" class="tag-link-816" title="7个话题" style="font-size: 12px;">旅行</a>
            <a href="" class="tag-link-153" title="48个话题" style="font-size: 12px;">文化</a>
            <a href="" class="tag-link-934" title="35个话题" style="font-size: 12px;">散文</a>
            <a href="" class="tag-link-671" title="15个话题" style="font-size: 12px;">教育</a>
            <a href="" class="tag-link-956" title="20个话题" style="font-size: 12px;">故事</a>
            <a href="" class="tag-link-976" title="5个话题" style="font-size: 12px;">技巧</a>
            <a href="" class="tag-link-220" title="139个话题" style="font-size: 12px;">感悟</a>
            <a href="" class="tag-link-131" title="77个话题" style="font-size: 12px;">情感</a>
            <a href="" class="tag-link-988" title="8个话题" style="font-size: 12px;">思绪</a>
            <a href="" class="tag-link-178" title="10个话题" style="font-size: 12px;">心情</a>
            <a href="" class="tag-link-95" title="150个话题" style="font-size: 12px;">影评</a>
            <a href="" class="tag-link-348" title="11个话题" style="font-size: 12px;">婚姻</a>
            <a href="" class="tag-link-223" title="24个话题" style="font-size: 12px;">回忆</a>
            <a href="" class="tag-link-917" title="8个话题" style="font-size: 12px;">商业</a>
            <a href="" class="tag-link-173" title="64个话题" style="font-size: 12px;">历史人物</a>
            <a href="" class="tag-link-75" title="108个话题" style="font-size: 12px;">历史</a>
            <a href="" class="tag-link-299" title="7个话题" style="font-size: 12px;">励志</a>
            <a href="" class="tag-link-874" title="18个话题" style="font-size: 12px;">剧评</a>
            <a href="" class="tag-link-46" title="86个话题" style="font-size: 12px;">冷笑话</a>
            <a href="" class="tag-link-581" title="21个话题" style="font-size: 12px;">健康</a>
            <a href="" class="tag-link-113" title="151个话题" style="font-size: 12px;">人生</a>
            <a href="" class="tag-link-730" title="61个话题" style="font-size: 12px;">人物</a>
            <a href="" class="tag-link-91" title="16个话题" style="font-size: 12px;">亲情</a>
            <a href="" class="tag-link-38" title="60个话题" style="font-size: 12px;">互联网</a>
            <a href="" class="tag-link-32" title="119个话题" style="font-size: 12px;">书评</a>
            <a href="" class="tag-link-37" title="57个话题" style="font-size: 12px;">IT</a>
        </aside>
    </div>
    <div id="tinbookmark-2" class="widget widget_tinbookmark">
        <h3><span class="widget-title">友情链接</span></h3>
        <div class="tinbookmark">
            <ul>
                <li class="tinbookmark-list list-left"><i class="fa fa-angle-right"></i><a href="http://www.lmonkey.com" title="柏拉图" target="_blank">柏拉图</a></li>
                <li class="tinbookmark-list list-right"><i class="fa fa-angle-right"></i><a href="http://www.lmonkey.com" title="青年说" target="_blank">青年说</a></li>
                <li class="tinbookmark-list list-left"><i class="fa fa-angle-right"></i><a href="http://lmonkey.com" title="杂时代" target="_blank">杂时代</a></li>
                <li class="tinbookmark-list list-right"><i class="fa fa-angle-right"></i><a href="http://lmonkey.com" title="书啦圈" target="_blank">书啦圈</a></li>
                <li class="tinbookmark-list list-left"><i class="fa fa-angle-right"></i><a href="http://www.lmonkey.com" title="练字网" target="_blank">练字网</a></li>
                <li class="tinbookmark-list list-right"><i class="fa fa-angle-right"></i><a href="http://www.lmonkey.com" title="听雾读书" target="_blank">听雾读书</a></li>
                <li class="tinbookmark-list list-left"><i class="fa fa-angle-right"></i><a href="http://www.lmonkey.com" title="柳苑文学" target="_blank">柳苑文学</a></li>
                <li class="tinbookmark-list list-right"><i class="fa fa-angle-right"></i><a href="http://www.lmonkey.com" title="於菟阅读博客" target="_blank">於菟阅读博客</a></li>
                <li class="tinbookmark-list list-left"><i class="fa fa-angle-right"></i><a href="http://www.lmonkey.com" title="饭后茶娱" target="_blank">饭后茶娱</a></li>
                <li class="tinbookmark-list list-right"><i class="fa fa-angle-right"></i><a href="http://www.lmonkey.com" title="博客大全" target="_blank">博客大全</a></li>
                <li class="tinbookmark-list list-left"><i class="fa fa-angle-right"></i><a href="http://www.lmonkey.com" title="DMOZ目录" target="_blank">DMOZ目录</a></li>
            </ul>
        </div>
    </div>
    <div id="text-12" class="widget widget_text">
        <div class="textwidget">
            <script type="text/javascript">
                (function(win,doc){
                    var s = doc.createElement("script"), h = doc.getElementsByTagName("head")[0];
                    if (!win.alimamatk_show) {
                        s.charset = "utf-8";
                        s.async = true;
                        s.src = "http://a.alimama.cn/tkapi.js";
                        h.insertBefore(s, h.firstChild);
                    };
                    var o = {
                        pid: "mm_31202157_7418138_30178413",/*推广单元ID，用于区分不同的推广渠道*/
                        appkey: "",/*通过TOP平台申请的appkey，设置后引导成交会关联appkey*/
                        unid: "",/*自定义统计字段*/
                        type: "click" /* click 组件的入口标志 （使用click组建必设）*/
                    };
                    win.alimamatk_onload = win.alimamatk_onload || [];
                    win.alimamatk_onload.push(o);
                })(window,document);
            </script>
            <p align="center"><a data-type="3" data-tmpl="320x250" data-tmplid="187" data-rd="2" data-style="2" data-border="1" href="#"></a></p>
        </div>
    </div>
    <div id="text-14" class="widget widget_text">
        <div class="textwidget">
            <p><a href="#" target="_blank"><img src="/home/images/20150928153704_4466.jpg" alt="" /></a></p>
        </div>
    </div>
    <div id="tinsitestatistic-3" class="widget widget_tinsitestatistic">
        <ul>
            <li>日志总数：<span>1934</span> 篇</li>
            <li> 评论总数：<span>627</span> 条</li>
            <li>标签数量：<span>64</span> 个</li>
            <li>链接总数：<span>11</span> 个</li>
            <li>建站日期：<span>2013-04-05</span></li>
            <li>运行天数：<span>1279</span> 天</li>
            <li>最后更新：<span>2016-9-30</span></li>
        </ul>
        <div class="clear"></div>
    </div>
    <div id="meta-3" class="widget widget_meta">
        <h3><span class="widget-title">小编管理</span></h3>
        <ul>
            <li><a href="https://www.lmonkey.com">登录</a></li>
            <li><a href="https://www.lmonkey.com">文章<abbr title="Really Simple Syndication">RSS</abbr></a></li>
            <li><a href="https://www.lmonkey.com/">评论<abbr title="Really Simple Syndication">RSS</abbr></a></li>
            <li><a href="https://www.lmonkey.com/"" title="基于WordPress，一个优美、先进的个人信息发布平台。">WordPress.org</a></li>
        </ul>
    </div>
    <div class="floatwidget-container">
    </div>
</div>
<script type="text/javascript">
    $('.site_loading').animate({'width':'78%'},50);  //第三个节点
</script>