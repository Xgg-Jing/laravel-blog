<link rel="stylesheet" href="{{ asset('admin/css/font.css') }}">
<link rel="stylesheet" href="{{ asset('admin/css/xadmin.css') }}">