<script type="text/javascript" src="{{ asset('home/js/jquery.min.js?ver=4.3.6') }}"></script>
<script type="text/javascript" src="{{ asset('home/js/lazyload.js') }}"></script>
<!-- IE Fix for HTML5 Tags -->
<!--[if lt IE 9]>
<script src="{{ asset('home/js/html5.js')}}"></script>
<script src="{{ asset('home/js/css3-mediaqueries.js')}}"></script>
<script src="{{ asset('home/js/PIE_IE678.js')}}"></script>
<link rel="stylesheet" type="text/css" href="{{ asset('home/css/iefix.css')}}"  media="all" />
<![endif]-->
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="{{ asset('home/css/font-awesome-ie7.min.css')}}"  media="all" />
<![endif]-->
<!--[if IE 6]>
<script src="{{ asset('home/js/kill-IE6.js')}}"></script>
<![endif]-->