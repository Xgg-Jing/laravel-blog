<aside id="navmenu-mobile">
    <div id="navmenu-mobile-wraper">
        <div class="mobile-login-field">
            <div id="login-box-mobile">
                <div class="login-box-mobile-form">
                    <button data-sign="0" class="btn btn-primary user-login">登录</button>
                    <button data-sign="1" class="btn btn-success user-reg">注册</button>
                </div>
            </div>
        </div>
        <ul id="menu-mobile" class="menu-mobile">
            <li id="menu-item-4324" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-4324"><a href="http://www.lmonkey.com">首页</a></li>
            <li id="menu-item-4316" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4316"><a href="https://www.lmonkey.com/deepreading">深阅读</a>
                <ul class="sub-menu">
                    <li id="menu-item-4317" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4317"><a href="lists.html?talk">七嘴八舌</a></li>
                    <li id="menu-item-4320" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4320"><a href="lists.html?prose">心灵花园</a></li>
                    <li id="menu-item-4318" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4318"><a href="lists.html?history">史海拾贝</a></li>
                    <li id="menu-item-4321" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4321"><a href="lists.html?read">读书书语</a></li>
                    <li id="menu-item-4322" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4322"><a href="lists.html?science">鲜活科学</a></li>
                    <li id="menu-item-4421" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4421"><a target="_blank" href="http://btmovie.net/category/appreciation">光影赏析</a></li>
                </ul> </li>
            <li id="menu-item-4305" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4305"><a href="https://www.lmonkey.com/shallowreading">浅阅读</a>
                <ul class="sub-menu">
                    <li id="menu-item-4314" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4314"><a href="https://www.lmonkey.com/shallowreading/vision">新视野</a></li>
                    <li id="menu-item-4315" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4315"><a href="https://www.lmonkey.com/shallowreading/phenomena">浮世绘</a></li>
                </ul> </li>
            <li id="menu-item-4302" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4302"><a href="https://www.lmonkey.com/series">强文连载</a></li>
            <li id="menu-item-4304" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4304"><a href="https://www.lmonkey.com/interest">有料</a>
                <ul class="sub-menu">
                    <li id="menu-item-4311" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4311"><a href="https://www.lmonkey.com/interest/encouragement">能量加油站</a></li>
                    <li id="menu-item-4310" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4310"><a href="https://www.lmonkey.com/interest/humorous">冷笑话精选</a></li>
                </ul> </li>
            <li id="menu-item-5019" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5019"><a target="_blank" href="http://qianshao.lmonkey.com">钱哨</a></li>
            <li id="menu-item-5018" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5018"><a href="https://www.lmonkey.com/liuyan">留言簿</a></li>
        </ul>
    </div>
</aside>