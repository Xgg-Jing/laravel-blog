<?php return array (
  'web_title' => '学习猿地Blog系统',
  'web_count' => '百度统计',
  'web_status' => '1',
//  'seo_title' => '无兄弟 不编程',
  'keywords' => '北京php培训,php视频教程,php培训,php基础视频,php实例视频,lamp视频教程',
  'description' => '学习猿地教育,专注PHP培训、Java培训、UI设计培训、HTML5培训、Linux培训、Python培训,选择IT培训机构,就来学习猿地!',
  'copyright' => 'Design by 学习猿地网 <a href="http://www.lmonkey.com" target="_blank">http://www.lmonkey.com</a>',
  'web_url' => 'http://www.lmonkey.com',
  'ICP' => '© 2013 - 2018                 <a target="_blank" rel="nofollow" href="http://www.lmonkey.com" style="display:inline-block;text-decoration:none;height:20px;line-height:20px;"><img src="/home/images/beiantubiao.png" style="float:left;" />京公网安备 53230102000151号</a> | Theme by                  <a href=http://www.lmonkey.com" target="_blank">学习猿地</a>.  |   |                  <a href="http://www.miitbeian.gov.cn/" target="_blank">1</a>',
);